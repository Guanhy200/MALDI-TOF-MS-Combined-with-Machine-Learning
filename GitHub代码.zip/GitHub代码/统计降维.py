# -*- coding: utf-8 -*-
"""
Created on Wed Jun 18 10:03:11 2025

@author: LENOVO
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Jun 18 08:46:00 2025

@author: LENOVO
"""

import pandas as pd
import numpy as np
from scipy import stats
from scipy.stats import shapiro, mannwhitneyu, ttest_ind
import os
from statsmodels.stats.multitest import multipletests

# 文件路径配置
input_path = r"C:\Users\LENOVO\Desktop\筛选转换数据\ESBL-nonESBL1.xlsx"
output_dir = r"C:\Users\LENOVO\Desktop\统计学降维数据"
os.makedirs(output_dir, exist_ok=True)  # 自动创建输出目录

# 数据读取与预处理
df = pd.read_excel(input_path)
sample_ids = df.iloc[:, 0]  # 第一列是样本号
group = df.iloc[:, 1]  # 第二列是分组信息
features = df.iloc[:, 2:]  # 第三列及之后是特征数据

# 初始化结果存储
results = {
    'feature': [],
    'test_type': [],
    'p_value': [],
    'q_value': []
}

# 遍历每个特征进行检验
for col in features.columns:
    # 获取两组数据并去除缺失值
    group0 = features[group == 0][col].dropna()
    group1 = features[group == 1][col].dropna()
    
    # 正态性检验（Shapiro-Wilk）
    _, p0 = shapiro(group0)
    _, p1 = shapiro(group1)
    
    # 选择检验方法
    if p0 > 0.05 and p1 > 0.05:
        # 方差齐性检验
        _, var_p = stats.levene(group0, group1)
        if var_p > 0.05:
            stat, p = ttest_ind(group0, group1)
            test_type = 't-test'
        else:
            stat, p = ttest_ind(group0, group1, equal_var=False)
            test_type = 'Welch t-test'
    else:
        stat, p = mannwhitneyu(group0, group1)
        test_type = 'Mann-Whitney U'
    
    # 记录结果
    results['feature'].append(col)
    results['test_type'].append(test_type)
    results['p_value'].append(p)

# 多重检验校正（FDR校正）
reject, q_values, _, _ = multipletests(results['p_value'], method='fdr_bh')
results['q_value'] = q_values

# 创建结果DataFrame
result_df = pd.DataFrame(results)

# 筛选显著特征
p_significant = result_df[result_df['p_value'] < 0.05]  # 仅p值显著
both_significant = result_df[(result_df['p_value'] < 0.05) & (result_df['q_value'] < 0.05)]  # 双重显著

# 保存结果文件
p_output = os.path.join(output_dir, "p_significant_features.xlsx")
both_output = os.path.join(output_dir, "both_significant_features.xlsx")
p_significant.to_excel(p_output, index=False)
both_significant.to_excel(both_output, index=False)

# 新增：提取双重显著特征的所有样本数据
if len(both_significant) > 0:
    # 获取双重显著特征的名称列表
    sig_features = both_significant['feature'].tolist()
    
    # 创建一个新的数据框，包含样本号、分组和双重显著特征的所有样本数据
    sig_samples_df = pd.DataFrame()
    sig_samples_df['样本号'] = df.iloc[:, 0]  # 样本号
    sig_samples_df['分组'] = df.iloc[:, 1]  # 分组信息
    
    # 只添加双重显著特征列
    for feature in sig_features:
        sig_samples_df[feature] = df[feature]
    
    # 保存双重显著特征的所有样本数据
    sig_samples_output = os.path.join(output_dir, "significant_features_all_samples.xlsx")
    sig_samples_df.to_excel(sig_samples_output, index=False)

# 生成统计报告
report_content = f"""
统计检验报告
{'='*40}

数据集信息：
- 总样本数：{len(df)}
- 特征数量：{len(features.columns)}
- 耐药组样本数（0组）：{sum(group == 0)}
- 敏感组样本数（1组）：{sum(group == 1)}

检验结果：
- 总检验特征数：{len(result_df)}
- 仅p值显著特征数（p < 0.05）：{len(p_significant)}
- 双重显著特征数（p < 0.05且q < 0.05）：{len(both_significant)}

检验方法分布：
{result_df['test_type'].value_counts().to_string()}

前3个仅p显著特征：
{p_significant.head(3).to_string(index=False)}

前3个双重显著特征：
{both_significant.head(3).to_string(index=False)}

校正信息：
- 校正方法：Benjamini-Hochberg FDR
- 显著性阈值：
  * 初级筛选：p < 0.05
  * 最终筛选：p < 0.05 且 q < 0.05

输出文件：
- 仅p显著特征：{os.path.basename(p_output)}
- 双重显著特征：{os.path.basename(both_output)}
- 双重显著特征的所有样本数据：{os.path.basename(sig_samples_output) if len(both_significant) > 0 else "无双重显著特征"}
"""

# 保存报告文件
report_path = os.path.join(output_dir, "statistical_report.txt")
with open(report_path, 'w', encoding='utf-8') as f:
    f.write(report_content.strip())

print(f"分析完成！结果已保存至：{output_dir}")
print(f"生成文件：\n- {os.path.basename(p_output)}\n- {os.path.basename(both_output)}")
if len(both_significant) > 0:
    print(f"- {os.path.basename(sig_samples_output)}")
print(f"- {os.path.basename(report_path)}")
