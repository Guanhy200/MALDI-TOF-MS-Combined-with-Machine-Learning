# -*- coding: utf-8 -*-
"""
Created on Mon Jun 30 14:47:39 2025

@author: LENOVO
"""

import pandas as pd
import numpy as np
from imblearn.over_sampling import BorderlineSMOTE

# 🎯 BorderlineSMOTE平衡 - 生成Excel表格

def borderline_smote_balance(input_file, output_file):
    """
    应用BorderlineSMOTE平衡样本并生成Excel文件
    专注于分类边界的样本生成
    """
    
    # 1. 读取数据
    print("📖 读取数据...")
    df = pd.read_excel(input_file)
    print(f"原始数据: {df.shape[0]}行 x {df.shape[1]}列")
    
    # 2. 数据分离
    sample_ids = df.iloc[:, 0]        # 第1列: 样本号
    y = df.iloc[:, 1].values          # 第2列: 分组标签
    X = df.iloc[:, 2:].values         # 其余列: 特征变量
    feature_names = df.columns[2:].tolist()
    
    # 3. 查看原始分布
    original_counts = pd.Series(y).value_counts().sort_index()
    print(f"\n📊 原始分布:")
    print(f"   耐药组 (0): {original_counts[0]} 样本")
    print(f"   敏感组 (1): {original_counts[1]} 样本")
    print(f"   不平衡比例: {original_counts[1]/original_counts[0]:.2f}:1")
    
    # 4. 应用BorderlineSMOTE
    print("\n🎯 应用BorderlineSMOTE平衡...")
    print("   - 专注于分类边界样本生成")
    print("   - 提升边界区域的分类性能")
    
    borderline_smote = BorderlineSMOTE(
        kind='borderline-1',          # 保守策略，专注DANGER样本
        sampling_strategy='auto',     # 自动平衡到1:1
        random_state=42,             # 确保结果可重复
        m_neighbors=5,               # 边界检测邻居数
        k_neighbors=5                # 样本生成邻居数
    )
    
    X_balanced, y_balanced = borderline_smote.fit_resample(X, y)
    
    # 5. 查看平衡后分布
    balanced_counts = pd.Series(y_balanced).value_counts().sort_index()
    print(f"\n✅ BorderlineSMOTE平衡后分布:")
    print(f"   耐药组 (0): {balanced_counts[0]} 样本")
    print(f"   敏感组 (1): {balanced_counts[1]} 样本")
    print(f"   新增耐药组样本: {balanced_counts[0] - original_counts[0]} 个")
    print(f"   总新增样本: {len(y_balanced) - len(y)} 个")
    
    # 6. 生成新样本编号
    new_sample_ids = []
    
    # 保留原始样本编号
    for i in range(len(y)):
        new_sample_ids.append(sample_ids.iloc[i])
    
    # 为BorderlineSMOTE合成样本编号
    synthetic_count = len(y_balanced) - len(y)
    for i in range(synthetic_count):
        new_sample_ids.append(f'BorderlineSMOTE_{i+1:03d}')
    
    # 7. 创建平衡后的数据框
    balanced_df = pd.DataFrame()
    balanced_df[df.columns[0]] = new_sample_ids  # 使用原始的第一列名
    balanced_df[df.columns[1]] = y_balanced      # 使用原始的第二列名
    
    # 添加所有特征列
    for i, col_name in enumerate(feature_names):
        balanced_df[col_name] = X_balanced[:, i]
    
    # 8. 保存Excel文件
    balanced_df.to_excel(output_file, index=False)
    print(f"\n💾 BorderlineSMOTE平衡后数据已保存: {output_file}")
    
    # 9. 数据质量检查
    print(f"\n🔍 数据质量检查:")
    print("各组特征统计 (前3个特征):")
    for i, feature in enumerate(feature_names[:3]):
        group0_mean = balanced_df[balanced_df[df.columns[1]] == 0][feature].mean()
        group1_mean = balanced_df[balanced_df[df.columns[1]] == 1][feature].mean()
        print(f"   {feature}: 耐药组均值={group0_mean:.3f}, 敏感组均值={group1_mean:.3f}")
    
    # 10. 显示预览
    print(f"\n📋 数据预览:")
    print("前5行 (原始样本):")
    print(balanced_df.head())
    print("\n后5行 (BorderlineSMOTE合成样本):")
    print(balanced_df.tail())
    
    return balanced_df

# 🎯 执行BorderlineSMOTE平衡
if __name__ == "__main__":
    
    # 设置文件路径
    input_file = r'C:\Users\LENOVO\Desktop\SMOTE平衡数据\CRKP-CSKP.xlsx'                         # 输入文件
    output_file = r'C:\Users\LENOVO\Desktop\SMOTE平衡数据\CRKP-CSKP_BorderlineSMOTE_Balanced.xlsx' # 输出文件
    
    # 执行BorderlineSMOTE平衡
    try:
        balanced_data = borderline_smote_balance(input_file, output_file)
        
        print(f"\n🎉 BorderlineSMOTE平衡完成!")
        print(f"📁 输入文件: CRKP-CSKP.xlsx")
        print(f"📁 输出文件: CRKP-CSKP_BorderlineSMOTE_Balanced.xlsx")
        print(f"📁 保存路径: C:\\Users\\LENOVO\\Desktop\\SMOTE平衡数据\\")
        print(f"📈 最终数据: {balanced_data.shape[0]}行 x {balanced_data.shape[1]}列")
        
        print(f"\n🌟 BorderlineSMOTE特点:")
        print("   ✅ 专注于分类边界样本生成")
        print("   ✅ 提升耐药组预测准确性")
        print("   ✅ 改善模型在困难样本上的性能")
        print("   ✅ 数据可直接用于机器学习建模")
        
    except Exception as e:
        print(f"❌ 错误: {e}")
        print("请检查:")
        print("   1. 文件路径是否正确")
        print("   2. 输入文件是否存在")
        print("   3. 输出文件夹是否有写入权限")
        print("   4. 数据格式是否正确 (第1列:样本号, 第2列:分组标签, 其余:特征)")

# 额外功能：边界样本分析
def analyze_boundary_samples(input_file):
    """
    可选功能：分析哪些样本被识别为边界样本
    """
    print("\n🔬 边界样本分析 (可选):")
    
    try:
        df = pd.read_excel(input_file)
        X = df.iloc[:, 2:].values
        y = df.iloc[:, 1].values
        
        from sklearn.neighbors import NearestNeighbors
        
        # 识别少数类样本
        minority_class = 0  # 假设0是耐药组
        minority_indices = np.where(y == minority_class)[0]
        
        # 为每个少数类样本分析边界类型
        nbrs = NearestNeighbors(n_neighbors=6)  # 5个邻居+自己
        nbrs.fit(X)
        
        boundary_types = {'SAFE': 0, 'DANGER': 0, 'NOISE': 0}
        
        for idx in minority_indices:
            _, neighbor_indices = nbrs.kneighbors([X[idx]])
            neighbor_indices = neighbor_indices[0][1:]  # 排除自己
            neighbor_labels = y[neighbor_indices]
            
            majority_count = np.sum(neighbor_labels == 1)  # 敏感组邻居数
            
            if majority_count == 0:
                boundary_types['SAFE'] += 1
            elif majority_count == 5:
                boundary_types['NOISE'] += 1
            else:
                boundary_types['DANGER'] += 1
        
        print(f"   耐药组边界分析:")
        print(f"   - SAFE样本 (安全):  {boundary_types['SAFE']} 个")
        print(f"   - DANGER样本 (边界): {boundary_types['DANGER']} 个 ⭐")
        print(f"   - NOISE样本 (噪声):  {boundary_types['NOISE']} 个")
        print(f"   - BorderlineSMOTE将主要基于 {boundary_types['DANGER']} 个DANGER样本生成新样本")
        
    except Exception as e:
        print(f"   边界分析出错: {e}")

# 如果需要边界分析，取消下面注释
# analyze_boundary_samples(r'C:\Users\LENOVO\Desktop\SMOTE平衡数据\CRKP-CSKP.xlsx')