# -*- coding: utf-8 -*-
"""
Created on Tue Jun 17 09:13:45 2025

@author: LENOVO
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler

# 读取 Excel 文件
df = pd.read_excel(r"C:\Users\LENOVO\Desktop\kpn质谱数据分组\ESBL-nonESBL.xlsx")
print("Excel 文件已读取")

# 处理缺失值：将 NaN 或空值替换为 0
df.fillna(0, inplace=True)
print("缺失值已处理，NaN 和空值替换为 0")

# 分离样本号、组别和峰强度数据
sample_numbers = df.iloc[:, 0]
groups = df.iloc[:, 1]
X = df.iloc[:, 2:]

# 记录原始峰数量
original_peak_count = X.shape[1]

# 频率过滤：去掉在 >90% 样本中为 0 的峰
zero_percentage = (X == 0).mean(axis=0)
X_freq_filtered = X.loc[:, zero_percentage <= 0.9]
filtered_peak_count = original_peak_count - X_freq_filtered.shape[1]
print(f"原始峰数量: {original_peak_count}")
print(f"频率过滤后，剩余峰数量: {X_freq_filtered.shape[1]}")
print(f"频率过滤去掉的峰数量: {filtered_peak_count}")

# 对数变换：X_log = np.log10(X_fil + 1)
X_log = np.log10(X_freq_filtered + 1)
print("已完成对数变换")

# Z-score 标准化
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_log)
print("已完成 Z-score 标准化")

# 创建新的 DataFrame，包含处理后的数据
processed_df = pd.DataFrame(X_scaled, columns=X_freq_filtered.columns)
processed_df.insert(0, 'Sample', sample_numbers)
processed_df.insert(1, 'Group', groups)

# 保存处理后的数据到指定目录
output_path = r"C:\Users\LENOVO\Desktop\筛选转换数据"
processed_df.to_excel(output_path, index=False)
print(f"处理后的数据已保存至 {output_path}")

# 确认样本数量未变
print(f"处理前样本数量: {df.shape[0]}")
print(f"处理后样本数量: {processed_df.shape[0]}")
print("未对样本进行过滤，仅对峰进行了频率过滤")
