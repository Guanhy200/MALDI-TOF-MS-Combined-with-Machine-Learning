# -*- coding: utf-8 -*-
"""
Created on Tue Jul 15 14:03:21 2025

@author: LENOVO
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Jun 17 09:13:45 2025

@author: LENOVO
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler

# 读取 Excel 文件
df = pd.read_excel(r"C:\Users\LENOVO\Desktop\kpn质谱数据分组\ESBL-nonESBL.xlsx")
print("Excel 文件已读取")

# 处理缺失值：将 NaN 或空值替换为 0
df.fillna(0, inplace=True)
print("缺失值已处理，NaN 和空值替换为 0")

# 分离样本号、组别和峰强度数据
sample_numbers = df.iloc[:, 0]
groups = df.iloc[:, 1]
X = df.iloc[:, 2:]

# 记录原始峰数量
original_peak_count = X.shape[1]

# 频率过滤：保留在>90%样本中有检出的峰（缺失<10%）
zero_percentage = (X == 0).mean(axis=0)
X_freq_filtered = X.loc[:, zero_percentage < 0.1]  # 修改：保留缺失<10%的峰
filtered_peak_count = original_peak_count - X_freq_filtered.shape[1]
print(f"原始峰数量: {original_peak_count}")
print(f"管家峰候选筛选后，剩余峰数量: {X_freq_filtered.shape[1]}")
print(f"频率过滤去掉的峰数量: {filtered_peak_count}")
print(f"保留的峰检出率均>90%")

# 对数变换：X_log = np.log10(X_fil + 1)
X_log = np.log10(X_freq_filtered + 1)
print("已完成对数变换")

# Z-score 标准化
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_log)
print("已完成 Z-score 标准化")

# 创建新的 DataFrame，包含处理后的数据
processed_df = pd.DataFrame(X_scaled, columns=X_freq_filtered.columns)
processed_df.insert(0, 'Sample', sample_numbers)
processed_df.insert(1, 'Group', groups)

# 保存处理后的数据到指定目录
output_path = r"C:\Users\LENOVO\Desktop\筛选转换数据_管家峰候选.xlsx"
processed_df.to_excel(output_path, index=False)
print(f"处理后的数据已保存至 {output_path}")

# 确认样本数量未变
print(f"处理前样本数量: {df.shape[0]}")
print(f"处理后样本数量: {processed_df.shape[0]}")
print("未对样本进行过滤，仅筛选出管家峰候选")

# 额外统计信息：显示保留峰的检出率分布
detection_rates = 1 - zero_percentage[zero_percentage < 0.1]
print(f"\n保留峰的检出率统计:")
print(f"最低检出率: {detection_rates.min():.3f}")
print(f"平均检出率: {detection_rates.mean():.3f}")
print(f"最高检出率: {detection_rates.max():.3f}")
print(f"检出率>95%的峰数量: {(detection_rates > 0.95).sum()}")
print(f"检出率>99%的峰数量: {(detection_rates > 0.99).sum()}")