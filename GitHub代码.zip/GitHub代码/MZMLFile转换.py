import openpyxl
from pyteomics import mzml
import os
import time
from openpyxl import Workbook

workspace_path = "C:/Users/LENOVO/Desktop/2024.7-2025.1"
#存储excel表头
excel_title = []
#存储编号和对应的数据
excel_data = []

# 读取 mzML 文件
#遍历文件夹下的文件
def recursive_listdir():
    files = os.listdir(workspace_path)
    for file_name in files:
        file_path = os.path.join(workspace_path, file_name)
        if(file_name.find(".mzml") > 0):
            code_num = getCodeNum(file_name)

            data_arr = []
            with mzml.read(file_path) as reader:
                for spectrum in reader:
                    # 获取基础信息
                    # scan_id = spectrum["id"]
                    # ms_level = spectrum["ms level"]
                    # retention_time = spectrum["scanList"]["scan"][0]["scan start time"]
                    # 获取质谱数据（m/z 和强度）
                    if "m/z array" in spectrum and "intensity array" in spectrum:
                        mz_matrix = spectrum["m/z array"]
                        intensity_matrix = spectrum["intensity array"]

                        for i in range(len(intensity_matrix)):
                            title_num = int(mz_matrix[i])
                            #插入表头数据
                            appendToExcelTitle(title_num)
                            #拼接intensity
                            data_arr.append({"titleNum": title_num, "data": intensity_matrix[i]})

            excel_data.append({"codeNum": code_num, "dataObj": data_arr})
    #写入excel
    writeToExcel()

#写入数据到excel
def writeToExcel():
    wb = Workbook()
    dest_filename = "data_" + str(time.time()*1000) + ".xlsx"
    excel_path = os.path.join(workspace_path, dest_filename)
    ws1 = wb.active
    print("len(excel_title)=============", len(excel_title))
    for i in range(len(excel_title)):
        #表头行
        ws1.cell(column=i+2, row=1, value= excel_title[i])

    #对excel_data进行排序
    sortExcelData()
    index = 1
    for k in range(len(excel_data)):
        data_obj = excel_data[k]
        #编号列
        ws1.cell(column = 1, row = k+2, value = data_obj["codeNum"])
        print("codeNum===============", str(index)+ ":" + data_obj["codeNum"])
        for j in range(len(excel_title)):
            ws1.cell(column = j+2, row = k+2, value= getIntensityByMzCode(data_obj["dataObj"], excel_title[j]))
        #每500条保存一次
        if(k==len(excel_data)-1 or index==500):
            wb.save(filename = excel_path)
            wb.close()
            wb = openpyxl.load_workbook(excel_path)
            ws1 = wb.active
            index = 0
        else:
            index += 1
    print("==============数据写入完毕==============")

#从名字种获取到编码
def getCodeNum(fileName):
    #g12   7个_
    fileNameSplitArr = fileName.split("_")
    if(len(fileNameSplitArr[2]) == 14):
        return fileNameSplitArr[2]
    else:
        return fileNameSplitArr[2] + "_" + fileNameSplitArr[3] + "_" + fileNameSplitArr[4]

#获取Intensity数据
def getIntensityByMzCode(dataArr, titleNum):
    dataStr = ""
    #有多个对应的，拼接到一起
    for obj in dataArr:
        if(obj["titleNum"] == titleNum):
            dataStr += str(obj["data"]) + ","
    #去掉末尾的逗号
    if(dataStr!=''):
        dataStr = dataStr[0: len(dataStr) -1 ]
    return dataStr

#按照从小打大的顺序排列，重复的不再插入
def appendToExcelTitle(titleValue):
    if(len(excel_title) == 0):
        excel_title.append(titleValue)
        return
    else:
        for i in range(len(excel_title)):
            #小于一个值的时候，和前一个值比较
            if(titleValue < excel_title[i]):
                #如何和前一个值不相等，插入到中间，如何相等不做处理
                if(titleValue == excel_title[i-1]):
                    return
                else:
                    excel_title.insert(i, titleValue)
                return
        #不小于任何值，插入到最后
        excel_title.append(titleValue)

#对excel数据进行排序
def sortExcelData():
    short_excel_data = []
    long_excel_data = []
    for data_obj in excel_data:
        if(data_obj["codeNum"].find("_") > 0):
            short_excel_data.append(data_obj)
        else:
            long_excel_data.append(data_obj)
    excel_data.clear()
    excel_data.extend(long_excel_data)
    excel_data.extend(short_excel_data)
    # print("excel_data=======" , excel_data)

recursive_listdir()
